/**
  * FUNÇÕES: são blocos de código que  podem ser reaproveitados
  * funções podem ou não ter nomes
  * podem ou não receber parámetros
  */
// criar ou declarar FUNÇÕES
function dizOla(nome) {
  //código 
  console.log('olá! ' + nome)
}
//INVOCAR / CHAMAR FUNÇÕES 
dizOla('Matheus')
dizOla('Ferreira')
dizOla('Santos')
dizOla('Souza')
//+-*/
// ADIÇÃO
function somaDoisNumeros(x, y) {
  const soma = x + y
  console.log(soma)
}
somaDoisNumeros(27, 86)
somaDoisNumeros(96, 106)

// SUBTRAÇÃO
function subtraiDoisNumeros(x, y) {
  const subtracao = x - y
  console.log(subtracao)
}
somaDoisNumeros(72, 85)
somaDoisNumeros(95, 17)

// MULTIPLICAÇÃO
function multiplicaçãoDoisNumeros(x, y) {
  const multiplicação = x * y
  console.log(multiplicação)
}
multiplicaçãoDoisNumeros(34, 86)
multiplicaçãoDoisNumeros(97, 54)


// DIVISÃO
function DIVISÃODoisNumeros(x, y) {
  const DIVISÃO = x / y
  console.log(DIVISÃO)
}
DIVISÃODoisNumeros(67, 48)
DIVISÃODoisNumeros(93, 24)
