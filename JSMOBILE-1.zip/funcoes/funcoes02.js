//DECLARAÇÃO OU CRIAÇÃO
function soma (n1, n2){
if(typeof n1 === 'number' && typeof n2 === 'number' ){
  const res = n1 + n2 ;
  alert('o resultado foi: ' + res)
} else {
  alert('por favor insira um número válido')
}
}
//INVOCAÇÃO OU CHAMAR
// soma(5,5)
// soma(5,15)
// soma(-3,5)

// DECLARAÇÃO OU CRIAÇÃO
function dados (nome, altura){
  if(typeof nome === 'string' && typeof altura === 'number' ){   
  alert("olá " + nome + " sua altura é: " + altura)
 
}else{
   alert('por favor insira dados corretamente')
}
}

//INVOCAÇÃO OU CHAMAR
dados("Matheus", 1.80)
dados(2, 1.80)