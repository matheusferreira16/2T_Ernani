const btnAlternar = document.getElementById('btn-alternar')
const imgLampada = document.getElementById('lampada')
const baseUrl = "https://b63312ca-8b26-49e8-8ce4-57d2d873d759-00-27gp9mbzm8c7o.janeway.replit.dev/"

btnAlternar.addEventListener('click', function() {
  if (imgLampada.src == baseUrl + 'lampada0.png') {
    imgLampada.src = "lampada2.png"
  } else {

    imgLampada.src = "lampada0.png"
  }

})