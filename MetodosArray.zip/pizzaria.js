/**
 * 1) Crie um algoritmo que faça o seguinte:
 a) pergunte o nome do cliente e armazene em uma variável
 b) cumprimente o cliente e pergunte qual pizza ele quer pedir
 c) enquanto ele não tiver feito 3 pedidos continue perguntando
 d) a cada pedido feito, adicione o sabor escolhido a um array
 e) ao final, informe ao cliente a quantidade de pizzas do pedido
 f) imprima quais pizzas foram pedidas
 */
let sabores = [] // CRIAR UM ARRAY VAZIO
let pedidos = 0

const cliente = prompt("ola, qual seu nome?")
// CHECAR COM IF SE O NOME DO USUÁRIO É EXISTE
if (cliente) {
  alert("ola, " + cliente + " seja bem vindo(a)!")
  // LOOP DE REPETIÇÃO INFINO (QUE RODA ENQUANTO UMA CONDIÇÃO FOR VERDADEIRA)
  while (pedidos < 3) {
    let sabor = prompt("qual sabor de pizza você deseja?")
    if (sabor) {
      sabores.push(sabor) // ENVIAR PARA NOSSA LISTA
      alert("pedido recebido!")
      pedidos = pedidos + 1 // ACÚMULAR VALORES
    }
  }
  // INPRIMIR A LISTA 
  alert("pedido fechando com sucesso! olhe o seu log")
  console.log("--------------PIZZARIA KI-GOSTOSO--------------")
  console.log(sabores)
  console.log("------------------------------------------")

} else {
  alert("por favor, digite seu nome")
}
