// METODO DE ARRAY
const comidas = ['churrasco', 'pizza']
comidas[3] = 'sushi' // manual
comidas.push('berijela') // EMPURRANDO UM VALOR PARA O FINAL DA LISTA
comidas.pop() // RETIRA UM VALOR DO FINAL DA LISTA
comidas.shift() // RETIRA UM ELEMENTO DO INICIO
comidas.unshift('Mamão') // INSERIR UM ITEM NO INICIO DA LISTA

const tamanho = comidas.length
console.log("existem " + tamanho + " itens na lista") // CONTAGEM DE ITENS

console.log(comidas)
