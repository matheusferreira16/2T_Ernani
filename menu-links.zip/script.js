//selecionar com QUERYSELECTOR()
const vermelho = document.querySelector('.vermelho');
const verde = document.querySelector('.verde')
const azul = document.querySelector('.azul')
const amarelo = document.querySelector('.amarelo')
const conteudo = document.querySelector('.conteudo')
const bigText = document.querySelector('.bigText')
//alert(vermelho)

vermelho.addEventListener('click', function() {
  conteudo.style.backgroundColor = 'red'
  bigText.style.color = '#fff'
})

verde.addEventListener('click', function() {
  conteudo.style.backgroundColor = 'green'
  bigText.style.color = '#00ff00'
})

azul.addEventListener('click', function() {
  conteudo.style.backgroundColor = 'blue'
  bigText.style.color = '#0000ff'
})

amarelo.addEventListener('click', function() {
  conteudo.style.backgroundColor = 'yellow'
  bigText.style.color = '#ffff00'
})